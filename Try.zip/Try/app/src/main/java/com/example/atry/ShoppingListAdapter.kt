package com.example.atry

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class ShoppingListAdapter(var items: MutableList<String>) : RecyclerView.Adapter<ShoppingListViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShoppingListViewHolder {
            var view = LayoutInflater.from(parent.context).inflate(R.layout.shopping_list_viewholder,parent,false)
            return ShoppingListViewHolder(view)
    }

    override fun onBindViewHolder(holder: ShoppingListViewHolder, position: Int) {
            holder.itemTextView.text = items.get(position)
    }

    override fun getItemCount(): Int {
        return items.size
    }
}