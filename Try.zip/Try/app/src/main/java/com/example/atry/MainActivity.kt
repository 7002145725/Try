package com.example.atry
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    lateinit var itemlist : RecyclerView
    lateinit var shoppingListEditText :EditText
    lateinit var submit : Button

    var itemInList = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        itemlist=findViewById(R.id.shopping_list)
        itemlist.adapter =ShoppingListAdapter(itemInList)
        itemlist.layoutManager=LinearLayoutManager(this)
        shoppingListEditText=findViewById(R.id.shoppingListEditText)
        submit=findViewById(R.id.submit)

        submit.setOnClickListener(object : View.OnClickListener{
            override fun onClick(p0: View?) {
                itemInList.add(shoppingListEditText.text.toString())
                (itemlist.adapter as ShoppingListAdapter).notifyDataSetChanged()
                shoppingListEditText.text.clear()
            }
        })
    }
}